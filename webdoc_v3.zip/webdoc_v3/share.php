<ul class="share">
	<li>
		<a href="">
			<i class="fab fa-twitter"></i>
		</a>
	</li>
	<li>
		<a href="">
			<i class="fab fa-facebook"></i>
		</a>
	</li>
	<li>
		<a href="">
			<i class="fab fa-pinterest"></i>
		</a>
	</li>
	<li>
		<a href="">
			<i class="fa fa-linkedin"></i>
		</a>
	</li>
	<li>
		<a href="">
			<i class="fab fa-whatsapp"></i>
		</a>
	</li>
</ul>