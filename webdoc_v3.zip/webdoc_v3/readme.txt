ROOT

Pour le pôle développement :

	metadata.php = copier-coller les métadonnées de la page d'accueil
	
	reseaux.php
		ajouter liens vers les RS Twitter et Instagram (lignes 2 et 3)
		
	favicons.php
		ajouter les liens générés par Real Favicon Generator (URL absolue)
		
	manque 404.php
	manque humans.txt
	manque apropos.php
	
	index.php
		compléter les descriptions à partir de la ligne 67 (entre les balises p)
		
	CSS : responsivisation accueil + style print + responsivisation catégorie (finaliser)
	
	Attention : tous les changements de style se font dans css/new.css, ne pas toucher à main.css !!!
		
	Catégories :
		
		index.php => compléter le modèle Sasha page de catégorie + dupliquer pour chaque catégorie
			corriger les textes !!!!!
			attention : tous les titres en bas de casse avec les caractères accentués (les maj. sont dans le style)
			ajouter tous les liens vers les articles
		
		sportsdecombats.php => valider le modèle d'article (à éditer : titre, auteurs, chapô)
			contient : metadata_sportsdecombats.php = métadonnées + content_sportsdecombats.php (corps du texte)
			ajouter les liens dans la div "sidebar" vers les autres articles
		
		Lister les articles de chaque personnages :
			- nom du fichier qui devra correspondre (= URL)
			
		Finaliser le style bottom.php dans Sasha (index.php + sportsdecombat.php)
		
		Ajouter le fichier bottom.php dans le répertoire des autres personnages (quand il sera finalisé)
		
		Lier le fichier bottom à index.php et à article.php
		
		=> Conseil : travaillez d'abord sur Sasha, histoire de finaliser un personnage complètement avant de passer aux autres
		(cela va éviter de faire-défaire, il faut travailler avec méthode ET de manière très rigoureuse)

Pôle conception : 
	
	Tests : optimisation / utilisateurs
	
	Optimiser images : résolution / persos gif fond transparent

Laurence (finalisation) :	
	
	ajouter liens RS (Laurence) share.php (voir RS retenus)
	Analytics
	sitemap.xml