<!doctype html>
<html class="no-js" lang="FR=fr">

<head>
  <meta charset="utf-8">
  <title>Les visages du sport</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php require_once('metadata.php'); ?>
  <?php require_once('../favicons.php'); ?>
  <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
  <script>window.jQuery || document.write('<script src="js/vendor/jquery-3.2.1.min.js"><\/script>')</script> 
  <script src="https://kit.fontawesome.com/5d803a5a54.js" crossorigin="anonymous"></script>
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&family=Pacifico&display=swap" rel="stylesheet"> 
  <link rel="stylesheet" href="../css/normalize.css">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/main.css">
  <link rel="stylesheet" href="../css/new.css">
</head>
<body id="cat" class="elio-cat inside cat">
 
	<?php 
		require_once('../reseaux.php');
		require_once('navbar.php'); 
	?>
    
    <div class="container main-container">
		<div class="row"> 
            
			<div class="col col-lg-2 col-md-2 col-sm-2 col-6" id="catperso"> 
              <img src="../img/Elio.png" alt="elio"> 
            </div>
            
            <div class="col col-lg-4 col-md-4 col-sm-6 col-6">
               <div class="cadre">    
					<h4>Elio</h4>
					<p> Je suis élu·e au conseil municipal de ma commune depuis 15 ans. Chargé·e des sports, j’ai 56 ans et j’ai une pratique assidue de vélo et de natation. Je me bat tous les jours pour développer le budget des associations et clubs sportifs de ma ville. Même si je reste passionné·e, je suis parfois lassé du manque de moyens financiers, d’infrastructures, et la baisse des adhérents. 
 </p>					
				</div>
				<div class="resp">
					<div class="center">
						<img src="../img/elio.png" alt="elio"> 
					</div>
				</div>
            </div>
        
            <div class="col col-lg-6 col-md-6 col-sm-12 col-12" id="categories">
              
			  <section>
				<h2><a href="clubscovid19">Les clubs et la Covid-19, une relation qui s’essoufle </a></h2> 
				<div class="chapo">
					En raison de la crise du coronavirus, le nombre de licencié·e·s a diminué de 9,4% en un an. Les restrictions sanitaires sont, principalement, les causes de cette baisse pour les clubs amateurs.
				</div> 
			  </section>

			  <section>
				<h2><a href="esport">E-sport</a></h2>
				<div class="chapo">  
				CHAPO A DEFINIR ATTENTE VALIDATION
				</div>
			   </section>

			   <section>
				<h2><a href="clubsruraux">Club ruraux</a></h2> 
				<div class="chapo">
					CHAPO A DEFINIR ATTENTE VALIDATION
				</div>
			   </section>
			  
            </div>
            
        </div>
	</div>
	
		<footer id="footer">
			<div class="container">
				J2 - InfoCom Lannion &copy; 2021
			</div>
		</footer>
		
		<script src="../js/vendor/modernizr-3.11.2.min.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		<script src="../js/main.js"></script>
    </body> 
</html>