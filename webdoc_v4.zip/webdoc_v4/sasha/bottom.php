<div class="container">
	<div class="col-12" id="bottom">
		<figure id="fig1">
			<a href="sasha/index"><img src="../img/Sasha.png" alt="Sasha"></a>
		</figure>
			
		<figure id="fig2">
			<a href="charlie/index"><img src="../img/Charlie.png" alt="Charlie"></a>
		</figure>
			
		<figure id="fig3">
			<a href="alix/index"><img src="../img/Alix.png" alt="Alix"></a>
		</figure>
		  
		<figure id="fig4">
			<a href="elio/index"><img src="../img/Elio.png" alt="Elio"></a>
		</figure>

		<figure id="fig5">
			<a href="aylan/index"><img src="../img/Aylan.png" alt="Aylan"></a>
		</figure>
	</div>
</div>