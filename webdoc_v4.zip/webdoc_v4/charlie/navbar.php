	<header id="topnav">
		<div class="container">
            <h1><a href="../">LES VISAGES DU SPORT</a></h1>
		</div>
    </header>
	 
	<nav class="navbar">
		<div id="close">
			<i class="fas fa-times"></i>
		</div>
		
		<div class="resp">LES VISAGES DU SPORT</div>
		
		<ul class="menu">
			<li><a href="../">Accueil</a></li>
			<li id="nav_sasha"><a href="../sasha/index">Sasha</a></li>
			<li id="nav_charlie" class="active"><a href="index">Charlie</a></li>
			<li id="nav_alix"><a href= "../alix/index"> Alix</a></li>
			<li id="nav_elio"><a href= "../elio/index" id="Elio">Elio</a></li>
			<li id="nav_aylan"><a href= "../aylan/index">Aylan</a></li>
			<li class="separator"><a href= "../apropos">A propos</a></li>
		</ul>
    </nav>