Contenu page à propos kdjkjd kjdkjdk dkjkdd

<h4 class="inter">Un nouveau titre</h4>


<p>
	Suite d emon <strong>texte</strong>
</p>

<img src="img/monimage.jpg" alt="La rédaction J2 Lannion" />

