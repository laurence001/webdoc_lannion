<meta name="description" content="Les étudiants en journalisme de l'IUT de Lannion racontent la réalité du sport amateur en France, dans un webdocumentaire de quatorze enquêtes." />
<meta name="keywords" content="sport, société, Trégor, handicap, féminisme, Covid-19, santé, sports, Lannion, journalisme, e-sport, esport, adolescence, violences sexuelles, activité physique, IUT, IUT Lannion" />		
<meta property="og:type" content="webdocumentaire" /> 
<meta property="og:site_name" content="Les visages du sport" />
<meta property="og:determiner" content="auto" />
<meta property="og:locale" content="fr-FR" /> 
<meta property="og:website" content="https://lesvisagesdusport.infocomlannion.fr" /> 
<meta property="og:profile" content="@lesvisagesdusport" /> 
<meta property="og:title" content="Les visages du sport. Cinq histoires, des millions de voix" /> 
<meta name="og:url" content="https://lesvisagesdusport.infocomlannion.fr" />
<meta property="og:image" content="https://www.lesvisagesdusport.infocomlannion.fr/img/metadata/logo.png" /> 
<meta property="og:description" content="Les étudiants en journalisme de l'IUT de Lannion racontent la réalité du sport amateur en France, dans un webdocumentaire de quatorze enquêtes." /> 
<meta name="twitter:card" value="summary_large_image" /> 
<meta name="twitter:site" value="@lesvisagesdusport" />
<meta name="twitter:creator" value="@lesvisagesdusport" />
<meta property="twitter:title" content="Les visages du sport. Cinq histoires, des millions de voix" /> 
<meta name="twitter:url" content="https://lesvisagesdusport.infocomlannion.fr" /> 
<meta property="twitter:image" content="https://www.lesvisagesdusport.infocomlannion.fr/img/metadata/logo.png" /> 
<meta property="twitter:description" content="Les étudiants en journalisme de l'IUT de Lannion racontent la réalité du sport amateur en France, dans un webdocumentaire de quatorze enquêtes." /> 
<meta name="DC.Publisher" content="J2 Infocom Lannion" />
<meta name="DC.Date" content="2021-01-31">
<meta name="DC.Language" scheme="UTF-8" content="fr-FR" />
<meta name="DC.Subject" content="sports" />
<meta name="DC.Creator" content="Les visages du sport" /> 
<meta name="DC.Identifier" content="https://lesvisagesdusport.infocomlannion.fr" />
<meta property="DC.Title" content="Les visages du sport. Cinq histoires, des millions de voix" /> 
<meta property="DC.Description" content="Les étudiants en journalisme de l'IUT de Lannion racontent la réalité du sport amateur en France, dans un webdocumentaire de quatorze enquêtes." />