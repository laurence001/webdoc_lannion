<meta name="description" content="Le personnage d'Elio représente les thématiques liées aux inégalités d'accès au sport. Depuis 31 ans, elle vit dans un quartier populaire et les observe au quotidien." />
<meta name="keywords" content="quartiers populaires, QPV, inégalités, sport, sports, enquête, journalisme, précarité, pauvreté, richesse, social, société, banlieues, riches, quartiers, Lannion" />		
<meta property="og:type" content="webdocumentaire" /> 
<meta property="og:site_name" content="Les visages du sport" />
<meta property="og:determiner" content="auto" />
<meta property="og:locale" content="fr-FR" /> 
<meta property="og:website" content="https://lesvisagesdusport.infocomlannion.fr" /> 
<meta property="og:profile" content="@lesvisagesdusport" /> 
<meta property="og:title" content="Elio, visage de la lutte des classes" /> 
<meta name="og:url" content="https://lesvisagesdusport.infocomlannion.fr/elio/index" />
<meta property="og:image" content="https://www.lesvisagesdusport.infocomlannion.fr/img/metadata/logo.png" /> 
<meta property="og:description" content="Le personnage d'Elio représente les thématiques liées aux inégalités d'accès au sport. Depuis 31 ans, elle vit dans un quartier populaire et les observe au quotidien." /> 
<meta name="twitter:card" value="summary_large_image" /> 
<meta name="twitter:site" value="@lesvisagesdusport" />
<meta name="twitter:creator" value="@lesvisagesdusport" />
<meta property="twitter:title" content="Elio, visage de la lutte des classes" /> 
<meta name="twitter:url" content="https://lesvisagesdusport.infocomlannion.fr/elio/index" /> 
<meta property="twitter:image" content="https://www.lesvisagesdusport.infocomlannion.fr/img/metadata/logo.png" /> 
<meta property="twitter:description" content="Le personnage d'Elio représente les thématiques liées aux inégalités d'accès au sport. Depuis 31 ans, elle vit dans un quartier populaire et les observe au quotidien." /> 
<meta name="DC.Publisher" content="J2 Infocom Lannion" />
<meta name="DC.Date" content="2021-01-31">
<meta name="DC.Language" scheme="UTF-8" content="fr-FR" />
<meta name="DC.Subject" content="sports" />
<meta name="DC.Creator" content="Les visages du sport" /> 
<meta name="DC.Identifier" content="https://lesvisagesdusport.infocomlannion.fr/elio/index" />
<meta property="DC.Title" content="Elio, visage de la lutte des classes" /> 
<meta property="DC.Description" content="Le personnage d'Elio représente les thématiques liées aux inégalités d'accès au sport. Depuis 31 ans, elle vit dans un quartier populaire et les observe au quotidien." /> 