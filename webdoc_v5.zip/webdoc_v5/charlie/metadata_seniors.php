<meta name="description" content="Pendant les confinements, les seniors ont arrêté leurs pratiques sportives. Leurs corps en ont payé les conséquences en perdant en agilité." />
<meta name="keywords" content="sport-santé, sport, sports, santé, enquête, Lannion, activité sportive, course à pied, vieillesse, EHPAD, retraite, retraités, marche, seniors" />		
<meta property="og:type" content="article" /> 
<meta property="og:site_name" content="Les visages du sport" />
<meta property="og:determiner" content="auto" />
<meta property="og:locale" content="fr-FR" /> 
<meta property="og:website" content="https://lesvisagesdusport.infocomlannion.fr" /> 
<meta property="og:profile" content="@lesvisagesdusport" /> 
<meta property="og:title" content="Les ravages de l’inactivité chez les seniors" /> 
<meta name="og:url" content="https://lesvisagesdusport.infocomlannion.fr/charlie/seniors" />
<meta property="og:image" content="https://www.lesvisagesdusport.infocomlannion.fr/img/metadata/seniors.jpeg" /> 
<meta property="og:description" content="PPendant les confinements, les seniors ont arrêté leurs pratiques sportives. Leurs corps en ont payé les conséquences en perdant en agilité." /> 
<meta name="twitter:card" value="summary_large_image" /> 
<meta name="twitter:site" value="@lesvisagesdusport" />
<meta name="twitter:creator" value="@violettevauloup et @manuelmagrez" />
<meta property="twitter:title" content="Les ravages de l’inactivité chez les seniors" /> 
<meta name="twitter:url" content="https://lesvisagesdusport.infocomlannion.fr/charlie/seniors" /> 
<meta property="twitter:image" content="https://www.lesvisagesdusport.infocomlannion.fr/img/metadata/seniors.jpeg" /> 
<meta property="twitter:description" content="Pendant les confinements, les seniors ont arrêté leurs pratiques sportives. Leurs corps en ont payé les conséquences en perdant en agilité." /> 
<meta name="DC.Publisher" content="J2 Infocom Lannion" />
<meta name="DC.Date" content="2021-01-31">
<meta name="DC.Language" scheme="UTF-8" content="fr-FR" />
<meta name="DC.Subject" content="sports" />
<meta name="DC.Creator" content="Violette Vauloup et Manuel Magrez" /> 
<meta name="DC.Identifier" content="https://lesvisagesdusport.infocomlannion.fr/charlie/seniors" />
<meta property="DC.Title" content="Les ravages de l’inactivité chez les seniors" /> 
<meta property="DC.Description" content="Pendant les confinements, les seniors ont arrêté leurs pratiques sportives. Leurs corps en ont payé les conséquences en perdant en agilité." /> 