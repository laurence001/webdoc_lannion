<meta name="description" content="Pour soigner un cancer, certain.e.s optent pour le sport. Depuis 2016, pratiquer une activité sportive est reconnue comme un traitement contre la maladie." />
<meta name="keywords" content="sport-santé, sport, sports, santé, cancer, maladie, maladies, enquête, Lannion, guérison, remède, activité sportive, course à pied, traitement, vieillesse, thérapie" />		
<meta property="og:type" content="article" /> 
<meta property="og:site_name" content="Les visages du sport" />
<meta property="og:determiner" content="auto" />
<meta property="og:locale" content="fr-FR" /> 
<meta property="og:website" content="https://lesvisagesdusport.infocomlannion.fr" /> 
<meta property="og:profile" content="@lesvisagesdusport" /> 
<meta property="og:title" content="Le sport, un remède de taille contre le cancer" /> 
<meta name="og:url" content="https://lesvisagesdusport.infocomlannion.fr/charlie/cancer" />
<meta property="og:image" content="https://www.lesvisagesdusport.infocomlannion.fr/img/metadata/sportcancer.jpeg" /> 
<meta property="og:description" content="Pour soigner un cancer, certains.e.s optent pour le sport. Depuis 2016, pratiquer une activité sportive est reconnue comme un traitement contre la maladie." /> 
<meta name="twitter:card" value="summary_large_image" /> 
<meta name="twitter:site" value="@lesvisagesdusport" />
<meta name="twitter:creator" value="@ChloeEbrel et @mariaazee" />
<meta property="twitter:title" content="Le sport, un remède de taille contre le cancer" /> 
<meta name="twitter:url" content="https://lesvisagesdusport.infocomlannion.fr/charlie/cancer" /> 
<meta property="twitter:image" content="https://www.lesvisagesdusport.infocomlannion.fr/img/metadata/sportcancer.jpeg" /> 
<meta property="twitter:description" content="Pour soigner un cancer, certain.e.s optent pour le sport. Depuis 2016, pratiquer une activité sportive est reconnue comme un traitement contre la maladie." /> 
<meta name="DC.Publisher" content="J2 Infocom Lannion" />
<meta name="DC.Date" content="2021-01-31">
<meta name="DC.Language" scheme="UTF-8" content="fr-FR" />
<meta name="DC.Subject" content="sports" />
<meta name="DC.Creator" content="Chloé Ebrel et Maria Azé" /> 
<meta name="DC.Identifier" content="https://lesvisagesdusport.infocomlannion.fr/charlie/cancer" />
<meta property="DC.Title" content="Le sport, un remède de taille contre le cancer" /> 
<meta property="DC.Description" content="Pour soigner un cancer, certain.e.s optent pour le sport. Depuis 2016, pratiquer une activité sportive est reconnue comme un traitement contre la maladie." /> 