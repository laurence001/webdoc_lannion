<meta name="description" content="Le personnage de Charlie représente les thématiques liées au sport-santé. Il a 70 ans et se sert du sport pour garder la forme. Cela lui a aussi permis de mieux vivre son cancer." />
<meta name="keywords" content="vieillesse, sport-santé, sport, sports, santé, cancer, maladie, maladies, journalisme, enquête, Lannion, senior, guérison, forme, inactivité, âge, retraité" />		
<meta property="og:type" content="webdocumentaire" /> 
<meta property="og:site_name" content="Les visages du sport" />
<meta property="og:determiner" content="auto" />
<meta property="og:locale" content="fr-FR" /> 
<meta property="og:website" content="https://lesvisagesdusport.infocomlannion.fr" /> 
<meta property="og:profile" content="@lesvisagesdusport" /> 
<meta property="og:title" content="Charlie, visage du sport-santé" /> 
<meta name="og:url" content="https://lesvisagesdusport.infocomlannion.fr/charlie/index" />
<meta property="og:image" content="https://www.lesvisagesdusport.infocomlannion.fr/img/metadata/logo.png" /> 
<meta property="og:description" content="Le personnage de Charlie représente les thématiques liées au sport-santé. Il a 70 ans et se sert du sport pour garder la forme. Cela lui a aussi permis de mieux vivre son cancer." /> 
<meta name="twitter:card" value="summary_large_image" /> 
<meta name="twitter:site" value="@lesvisagesdusport" />
<meta name="twitter:creator" value="@lesvisagesdusport" />
<meta property="twitter:title" content="Charlie, visage du sport-santé" /> 
<meta name="twitter:url" content="https://lesvisagesdusport.infocomlannion.fr/charlie/index" /> 
<meta property="twitter:image" content="https://www.lesvisagesdusport.infocomlannion.fr/img/metadata/logo.png" /> 
<meta property="twitter:description" content="Le personnage de Charlie représente les thématiques liées au sport-santé. Il a 70 ans et se sert du sport pour garder la forme. Cela lui a aussi permis de mieux vivre son cancer." /> 
<meta name="DC.Publisher" content="J2 Infocom Lannion" />
<meta name="DC.Date" content="2021-01-31">
<meta name="DC.Language" scheme="UTF-8" content="fr-FR" />
<meta name="DC.Subject" content="sports" />
<meta name="DC.Creator" content="Les visages du sport" /> 
<meta name="DC.Identifier" content="https://lesvisagesdusport.infocomlannion.fr/charlie/index" />
<meta property="DC.Title" content="Charlie, visage du sport-santé" /> 
<meta property="DC.Description" content="Le personnage de Charlie représente les thématiques liées au sport-santé. Il a 70 ans et se sert du sport pour garder la forme. Cela lui a aussi permis de mieux vivre son cancer." /> 